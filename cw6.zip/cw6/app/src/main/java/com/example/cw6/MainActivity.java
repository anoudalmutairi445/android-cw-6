package com.example.cw6;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Movies enola = new Movies("Enola Holmes", "Millie Bobbie Brown", 6.9, 13, "drama");
        Movies charlie = new Movies("Charlie and the Chocolate Factory", "Jonny Depp",6.6,7,"Fantasy Fiction");

    }
}