package com.example.cw6;

public class Movies {

    private String title;
    private String mainactor;
    private Double movierate;
    private int pgrate;
    private String genre;

    public Movies(String title, String mainactor, Double movierate, int pngrate, String genre) {
        this.title = title;
        this.mainactor = mainactor;
        this.movierate = movierate;
        this.pgrate = pngrate;
        this.genre = genre;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMainactor() {
        return mainactor;
    }

    public void setMainactor(String mainactor) {
        this.mainactor = mainactor;
    }

    public Double getMovierate() {
        return movierate;
    }

    public void setMovierate(Double movierate) {
        this.movierate = movierate;
    }

    public int getPgrate() {
        return pgrate;
    }

    public void setPgrate(int pngrate) {
        this.pgrate = pngrate;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }
}
